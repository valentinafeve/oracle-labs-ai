resource "oci_objectstorage_bucket" "artifacts" {
  count = var.enable_object_storage_artifacts ? 1 : 0

  compartment_id = oci_identity_compartment.lab.id
  namespace      = data.oci_objectstorage_namespace.ns.namespace
  name           = local.bucket_name
  access_type    = "NoPublicAccess"
  storage_tier   = "Standard"
  versioning     = "Enabled"

  freeform_tags = var.freeform_tags
}

# Espera de consistencia para bucket + propagacion de politicas IAM
resource "time_sleep" "wait_bucket_and_iam_ready" {
  count = var.enable_object_storage_artifacts && var.enable_bucket_object_uploads && var.enable_phase_2 ? 1 : 0

  depends_on = [
    oci_objectstorage_bucket.artifacts,
    oci_identity_policy.lab_policy
  ]

  create_duration = "300s"
}

resource "tls_private_key" "api_signing_key" {
  algorithm = "RSA"
  rsa_bits  = 4096
}

resource "oci_identity_api_key" "lab_user_key" {
  user_id   = var.api_key_user_ocid
  key_value = tls_private_key.api_signing_key.public_key_pem
}

resource "oci_objectstorage_object" "api_private_key_pem" {
  count = var.enable_object_storage_artifacts && var.enable_bucket_object_uploads && var.store_api_private_key_in_bucket ? 1 : 0

  namespace    = data.oci_objectstorage_namespace.ns.namespace
  bucket       = oci_objectstorage_bucket.artifacts[0].name
  object       = "keys/oci_api_private_key.pem"
  content      = tls_private_key.api_signing_key.private_key_pem
  content_type = "application/x-pem-file"

  depends_on = [oci_objectstorage_bucket.artifacts, time_sleep.wait_bucket_and_iam_ready]
}

resource "oci_objectstorage_object" "api_public_key_pem" {
  count = var.enable_object_storage_artifacts && var.enable_bucket_object_uploads ? 1 : 0

  namespace    = data.oci_objectstorage_namespace.ns.namespace
  bucket       = oci_objectstorage_bucket.artifacts[0].name
  object       = "keys/oci_api_public_key.pem"
  content      = tls_private_key.api_signing_key.public_key_pem
  content_type = "application/x-pem-file"

  # Secuencial: despues de private key (si aplica)
  depends_on = [
    oci_objectstorage_bucket.artifacts,
    time_sleep.wait_bucket_and_iam_ready,
    oci_objectstorage_object.api_private_key_pem
  ]
}

resource "oci_objectstorage_object" "api_key_fingerprint" {
  count = var.enable_object_storage_artifacts && var.enable_bucket_object_uploads ? 1 : 0

  namespace    = data.oci_objectstorage_namespace.ns.namespace
  bucket       = oci_objectstorage_bucket.artifacts[0].name
  object       = "keys/oci_api_key_fingerprint.txt"
  content      = oci_identity_api_key.lab_user_key.fingerprint
  content_type = "text/plain"

  # Secuencial: despues de public key
  depends_on = [
    oci_objectstorage_bucket.artifacts,
    time_sleep.wait_bucket_and_iam_ready,
    oci_objectstorage_object.api_public_key_pem
  ]
}

resource "oci_objectstorage_object" "vm_ssh_private_key" {
  count = var.enable_object_storage_artifacts && var.enable_bucket_object_uploads && var.store_vm_ssh_keys_in_bucket && var.ssh_public_key == "" ? 1 : 0

  namespace    = data.oci_objectstorage_namespace.ns.namespace
  bucket       = oci_objectstorage_bucket.artifacts[0].name
  object       = "keys/vm_ssh_private_key.pem"
  content      = tls_private_key.vm_ssh_key[0].private_key_pem
  content_type = "application/x-pem-file"

  # Secuencial: despues de fingerprint
  depends_on = [
    oci_objectstorage_bucket.artifacts,
    time_sleep.wait_bucket_and_iam_ready,
    oci_objectstorage_object.api_key_fingerprint
  ]
}

resource "oci_objectstorage_object" "vm_ssh_public_key" {
  count = var.enable_object_storage_artifacts && var.enable_bucket_object_uploads && var.store_vm_ssh_keys_in_bucket && var.ssh_public_key == "" ? 1 : 0

  namespace    = data.oci_objectstorage_namespace.ns.namespace
  bucket       = oci_objectstorage_bucket.artifacts[0].name
  object       = "keys/vm_ssh_public_key.pub"
  content      = tls_private_key.vm_ssh_key[0].public_key_openssh
  content_type = "text/plain"

  # Secuencial: despues de vm private key
  depends_on = [
    oci_objectstorage_bucket.artifacts,
    time_sleep.wait_bucket_and_iam_ready,
    oci_objectstorage_object.vm_ssh_private_key
  ]
}

resource "oci_objectstorage_object" "api_config_profile" {
  count = var.enable_object_storage_artifacts && var.enable_bucket_object_uploads ? 1 : 0

  namespace = data.oci_objectstorage_namespace.ns.namespace
  bucket    = oci_objectstorage_bucket.artifacts[0].name
  object    = "keys/oci_config"
  content = join("\n", [
    "[DEFAULT]",
    format("user=%s", var.api_key_user_ocid),
    format("fingerprint=%s", oci_identity_api_key.lab_user_key.fingerprint),
    format("tenancy=%s", var.tenancy_ocid),
    format("region=%s", var.region),
    "key_file=<path to your private keyfile> # TODO"
  ])
  content_type = "text/plain"

  depends_on = [
    oci_objectstorage_bucket.artifacts,
    time_sleep.wait_bucket_and_iam_ready,
    oci_objectstorage_object.api_key_fingerprint
  ]
}
