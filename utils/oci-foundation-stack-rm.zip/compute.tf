resource "tls_private_key" "vm_ssh_key" {
  count = var.ssh_public_key == "" ? 1 : 0

  algorithm = "RSA"
  rsa_bits  = 4096
}
data "oci_core_images" "ol9_images" {
  compartment_id           = var.tenancy_ocid
  operating_system         = "Oracle Linux"
  operating_system_version = "9"
  shape                    = var.vm_shape
  sort_by                  = "TIMECREATED"
  sort_order               = "DESC"
}

resource "oci_core_instance" "docker_vm" {
  availability_domain = data.oci_identity_availability_domains.ads.availability_domains[0].name
  compartment_id      = oci_identity_compartment.lab.id
  display_name        = var.vm_display_name
  shape               = var.vm_shape

  shape_config {
    ocpus         = var.vm_ocpus
    memory_in_gbs = var.vm_memory_in_gbs
  }

  create_vnic_details {
    subnet_id        = oci_core_subnet.public_subnet.id
    assign_public_ip = true
    display_name     = "${var.vm_display_name}-vnic"
    hostname_label   = "dockerhost"
  }

  source_details {
    source_type             = "image"
    source_id               = data.oci_core_images.ol9_images.images[0].id
    boot_volume_size_in_gbs = var.vm_boot_volume_size_in_gbs
  }

  metadata = {
    ssh_authorized_keys = local.effective_ssh_public_key
    user_data           = local.vm_user_data
  }

  freeform_tags = var.freeform_tags
}

