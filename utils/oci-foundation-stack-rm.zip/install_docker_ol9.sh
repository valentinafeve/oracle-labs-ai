#!/bin/bash
set -euo pipefail

# Instala Docker en Oracle Linux 9 sin actualizar todos los paquetes del sistema.
# Evitamos `dnf update -y` para no provocar upgrades masivos no planificados.

dnf -y install dnf-plugins-core
dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo

# Instala solo los paquetes requeridos por Docker.
dnf -y install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

systemctl enable --now docker
usermod -aG docker opc

# Verificación mínima (no falla el bootstrap si este comando falla por timing).
docker --version || true
