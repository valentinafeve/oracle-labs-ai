resource "oci_database_autonomous_database" "atp" {
  compartment_id = oci_identity_compartment.lab.id

  display_name = var.atp_display_name
  db_name      = var.atp_db_name

  db_workload             = "OLTP"
  compute_model           = "ECPU"
  compute_count           = 4
  admin_password          = var.atp_admin_password
  license_model           = var.atp_license_model
  is_auto_scaling_enabled = var.atp_auto_scaling

  # Provider OCI actual: soporta TB en este recurso.
  data_storage_size_in_tbs = var.atp_data_storage_tbs

  freeform_tags = var.freeform_tags
}
