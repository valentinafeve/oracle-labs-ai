resource "oci_ai_data_platform_ai_data_platform" "aidp_workbench" {
  count = var.enable_aidp_workbench ? 1 : 0

  compartment_id         = oci_identity_compartment.lab.id
  display_name           = var.aidp_display_name
  default_workspace_name = var.aidp_workspace_name
  ai_data_platform_type  = var.aidp_type

  freeform_tags = var.freeform_tags

  depends_on = [
    oci_identity_policy.lab_policy,
    oci_identity_policy.aidp_policy,
    time_sleep.wait_aidp_policy_ready
  ]
}
