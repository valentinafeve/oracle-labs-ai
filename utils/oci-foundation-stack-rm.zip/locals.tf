resource "random_string" "suffix" {
  length  = 6
  upper   = false
  special = false
}

locals {
  normalized_compartment_name = lower(replace(var.compartment_name, "_", "-"))
  bucket_name                 = "${var.bucket_name_prefix}-${random_string.suffix.result}"

  docker_install_script_fallback = <<-EOT
    #!/bin/bash
    set -euo pipefail

    # Instala Docker en Oracle Linux 9 sin actualizar todos los paquetes del sistema.
    dnf -y install dnf-plugins-core
    dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
    dnf -y install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

    systemctl enable --now docker
    usermod -aG docker opc
    docker --version || true
  EOT

  docker_install_script_content = fileexists("${path.module}/scripts/install_docker_ol9.sh") ? file("${path.module}/scripts/install_docker_ol9.sh") : local.docker_install_script_fallback
  vm_user_data                  = base64encode(local.docker_install_script_content)
  effective_ssh_public_key      = var.ssh_public_key != "" ? var.ssh_public_key : tls_private_key.vm_ssh_key[0].public_key_openssh
}

data "oci_identity_availability_domains" "ads" {
  compartment_id = var.tenancy_ocid
}

data "oci_objectstorage_namespace" "ns" {
  compartment_id = var.tenancy_ocid
}
