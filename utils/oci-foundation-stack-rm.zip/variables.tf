############################################
# Tenancy and Identity
############################################

variable "tenancy_ocid" {
  description = "OCID del tenancy."
  type        = string
}

variable "region" {
  description = "Región OCI, por ejemplo us-chicago-1."
  type        = string
}

variable "api_key_user_ocid" {
  description = "OCID del usuario IAM al que se le creará la API key."
  type        = string
}

variable "policy_group_name" {
  description = "Nombre del grupo IAM para políticas least-privilege."
  type        = string
  default     = "Administrators"
}

variable "policy_name" {
  description = "Nombre de la política IAM. En labs suele ser 'ora26ai'."
  type        = string
  default     = "ora26ai"
}

variable "allow_any_user_manage_all_resources" {
  description = "Si true, crea la política abierta de laboratorio: Allow any-user to manage all-resources..."
  type        = bool
  default     = false
}

variable "resource_manager_service_principal" {
  description = "Principal de servicio opcional para policy de Object Storage (ej: resource-manager o resourcemanager). Dejar vacio para omitir."
  type        = string
  default     = ""
}

############################################
# Compartment
############################################

variable "compartment_name" {
  description = "Nombre del compartment del laboratorio."
  type        = string
  default     = "ora26ai"
}

variable "compartment_description" {
  description = "Descripción del compartment del laboratorio."
  type        = string
  default     = "Testing AI in Oracle"
}

############################################
# Networking
############################################

variable "vcn_display_name" {
  description = "Nombre visible de la VCN."
  type        = string
  default     = "vcn-agent"
}

variable "public_subnet_display_name" {
  description = "Nombre visible de la subnet pública."
  type        = string
  default     = "public-subnet"
}

variable "vcn_cidr" {
  description = "CIDR del VCN."
  type        = string
  default     = "10.20.0.0/16"
}

variable "public_subnet_cidr" {
  description = "CIDR de la subnet pública para la VM."
  type        = string
  default     = "10.20.10.0/24"
}

variable "ssh_allowed_cidr" {
  description = "CIDR permitido para SSH. Default abierto para laboratorio."
  type        = string
  default     = "0.0.0.0/0"
}

variable "enable_public_app_ports" {
  description = "Si true, abre puertos TCP de aplicación en la security list pública."
  type        = bool
  default     = true
}

variable "app_ports_cidr" {
  description = "CIDR para puertos de aplicación cuando enable_public_app_ports=true. Default abierto para laboratorio."
  type        = string
  default     = "0.0.0.0/0"
}

############################################
# Compute VM
############################################

variable "vm_display_name" {
  description = "Nombre visible de la instancia de cómputo."
  type        = string
  default     = "AgentFactoryVM"
}

variable "vm_shape" {
  description = "Shape de la VM."
  type        = string
  default     = "VM.Standard.E5.Flex"
}

variable "vm_ocpus" {
  description = "OCPUs para la shape flex."
  type        = number
  default     = 2
}

variable "vm_memory_in_gbs" {
  description = "Memoria en GB para la shape flex."
  type        = number
  default     = 32
}

variable "vm_boot_volume_size_in_gbs" {
  description = "Tamaño del boot volume en GB."
  type        = number
  default     = 100
}

variable "ssh_public_key" {
  description = "Llave pública SSH opcional. Si queda vacía, Terraform genera par RSA automáticamente para la VM."
  type        = string
  default     = ""
}

############################################
# Autonomous Database (ATP)
############################################

variable "atp_display_name" {
  description = "Nombre visible de la ATP."
  type        = string
  default     = "ora26ai-atp"
}

variable "atp_db_name" {
  description = "Nombre corto de la ATP (sin guiones)."
  type        = string
  default     = "ORA26AI"
}

variable "atp_admin_password" {
  description = "Password del usuario ADMIN de la ATP. Default laboratorio: Welcome123456$"
  type        = string
  sensitive   = true
  default     = "Welcome123456$"

  validation {
    condition = (
      length(var.atp_admin_password) >= 12 &&
      length(var.atp_admin_password) <= 30 &&
      can(regex("[A-Z]", var.atp_admin_password)) &&
      can(regex("[a-z]", var.atp_admin_password)) &&
      can(regex("[0-9]", var.atp_admin_password)) &&
      !can(regex("\"", var.atp_admin_password)) &&
      !can(regex("(?i)admin", var.atp_admin_password))
    )
    error_message = "La contraseña ATP debe tener 12-30 caracteres, mayúscula, minúscula, número y no contener \" ni 'admin'."
  }
}

variable "atp_license_model" {
  description = "Modelo de licenciamiento de ATP."
  type        = string
  default     = "LICENSE_INCLUDED"
}

variable "atp_auto_scaling" {
  description = "Habilita auto-scaling de cómputo en ATP."
  type        = bool
  default     = true
}

variable "atp_data_storage_tbs" {
  description = "Almacenamiento ATP en TB (provider actual)."
  type        = number
  default     = 1
}

############################################
# Object Storage
############################################

variable "bucket_name_prefix" {
  description = "Prefijo del bucket para artefactos del laboratorio."
  type        = string
  default     = "ora26ai-secrets"
}

variable "enable_object_storage_artifacts" {
  description = "Si true, crea bucket para artefactos."
  type        = bool
  default     = true
}

variable "enable_bucket_object_uploads" {
  description = "Si true, sube objetos al bucket (llaves/fingerprint)."
  type        = bool
  default     = true
}

variable "enable_phase_2" {
  description = "Controla la fase de subida de objetos al bucket tras crear infraestructura base."
  type        = bool
  default     = true
}

variable "store_api_private_key_in_bucket" {
  description = "Si true, guarda la llave privada PEM en el bucket (requiere enable_object_storage_artifacts=true y enable_bucket_object_uploads=true)."
  type        = bool
  default     = true
}

variable "store_vm_ssh_keys_in_bucket" {
  description = "Si true, guarda llaves SSH autogeneradas en bucket (requiere enable_object_storage_artifacts=true y enable_bucket_object_uploads=true)."
  type        = bool
  default     = true
}

############################################
# Tags
############################################

variable "freeform_tags" {
  description = "Etiquetas libres aplicadas a los recursos."
  type        = map(string)
  default = {
    project = "oracle-labs-ai"
    owner   = "lab-team"
  }
}


############################################
# OCI AI Data Platform (AIDP Workbench)
############################################

variable "enable_aidp_workbench" {
  description = "Si true, crea OCI AI Data Platform Workbench."
  type        = bool
  default     = true
}

variable "aidp_display_name" {
  description = "Nombre visible del servicio AIDP Workbench."
  type        = string
  default     = "AIDP_DEMO"
}

variable "aidp_workspace_name" {
  description = "Nombre del workspace por defecto de AIDP Workbench."
  type        = string
  default     = "default-workspace"
}

variable "aidp_type" {
  description = "Tipo de AI Data Platform. Para Workbench normalmente usar WORKBENCH."
  type        = string
  default     = "WORKBENCH"
}







variable "expose_sensitive_credentials_in_outputs" {
  description = "Si true, imprime llaves/credenciales en outputs para copia manual (solo laboratorio)."
  type        = bool
  default     = true
}





variable "enable_aidp_iam_policies" {
  description = "Si true, agrega políticas IAM recomendadas para crear/operar AIDP Workbench."
  type        = bool
  default     = true
}

variable "aidp_use_tenancy_policies" {
  description = "Si true, usa la variante de políticas AIDP de alcance tenancy (recomendada para labs). Si false, usa alcance compartment."
  type        = bool
  default     = true
}
