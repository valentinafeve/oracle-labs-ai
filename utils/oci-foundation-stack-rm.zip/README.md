# OCI Foundation Stack (Labs + Seguro)

Este stack Terraform fue ajustado para:

- Mantener nombres consistentes con los labs analizados (especialmente `08-workshop-rag-with-oracle-db`).
- Configuración abierta por defecto para laboratorio guiado.
- Permitir despliegue rápido con botón de Resource Manager.
- Crear opcionalmente OCI AI Data Platform Workbench (AIDP).

## Alineación de nombres con laboratorios

Valores por defecto alineados:

- `compartment_name`: `ora26ai`
- `policy_name`: `ora26ai`
- `vcn_display_name`: `vcn-agent`
- `vm_display_name`: `AgentFactoryVM`
- `atp_display_name`: `ora26ai-atp`
- `atp_db_name`: `ORA26AI`
- `aidp_display_name`: `AIDP_DEMO`

## Configuración por defecto (laboratorio)

- Política IAM en modo least-privilege (grupo), con opción legacy `any-user`.
- SSH abierto por defecto (`ssh_allowed_cidr = 0.0.0.0/0`).
- Puertos 8080/1521 abiertos por defecto (`enable_public_app_ports = true`, `app_ports_cidr = 0.0.0.0/0`).
- Password ATP por defecto: `Welcome123456$`.
- Si `ssh_public_key` se deja vacío, Terraform genera automáticamente un par SSH para la VM.
- Guardado de llaves en bucket es opcional (`store_vm_ssh_keys_in_bucket`) y requiere `enable_object_storage_artifacts = true`.
- Bucket con `NoPublicAccess` y `versioning` habilitado.
- Script de VM instala Docker sin `dnf update` global del sistema.

## Política previa recomendada para Resource Manager

Para desplegar con Resource Manager usando un usuario del grupo `Administrators`, define estas políticas a nivel tenancy:

```text
Allow group Administrators to manage orm-stacks in tenancy
Allow group Administrators to manage orm-jobs in tenancy
```

Si en tu tenancy necesitas policy explícita de servicio para Object Storage, define manualmente el principal correcto con la variable:

- `resource_manager_service_principal` (ejemplo común: `resource-manager` o `resourcemanager`)

Si no estás seguro, déjala vacía (default) para no bloquear la creación de la policy.

## Política previa para AIDP (importante)

Si `enable_aidp_workbench=true`, este stack ahora crea una política separada `"<policy_name>-aidp"` antes de crear AIDP y espera propagación IAM.

Para evitar fallos por Identity Domains en algunos tenants trial:

- Usa `policy_group_name = "Default/Administrators"` si tu tenancy trabaja con nombre de grupo calificado por dominio.
- Mantén `enable_aidp_iam_policies = true`.
- Mantén `aidp_use_tenancy_policies = true` (modo más permisivo para laboratorio).

Referencia oficial de Oracle:

- https://docs.oracle.com/en/cloud/paas/ai-data-platform/aidug/iam-policies-oracle-ai-data-platform.html

Notas para OCI Trial:

- Estas políticas habilitan creación/ejecución del stack desde Resource Manager.
- Si además el job requiere crear recursos en otros servicios (network, compute, database, object storage, iam), ese mismo grupo también debe tener permisos suficientes sobre esos servicios en tenancy o en los compartments objetivo.
- Si despliegas con `terraform` local (sin Resource Manager), normalmente no necesitas `orm-*`.

## Recursos que crea

- Compartment.
- VCN + subnet pública + IGW + route table + security list.
- VM Oracle Linux 9.
- ATP OLTP con 4 ECPU y almacenamiento en TB (`atp_data_storage_tbs`, default 1).
- OCI AI Data Platform Workbench opcional (`enable_aidp_workbench=true` por defecto).
- Bucket para artefactos (`enable_object_storage_artifacts=true` por defecto).
- Carga de objetos al bucket controlada por `enable_bucket_object_uploads` (default true).
- Si activas uploads, el stack espera propagación IAM/Object Storage antes de subir objetos.

## Despliegue paso a paso (Resource Manager)

### Opción A: Usando el botón "Deploy to Oracle Cloud"

1. Empaqueta esta carpeta (`utils/oci-foundation-stack`) en un `.zip`.
2. Sube el `.zip` a un bucket de Object Storage.
3. Crea un PAR (Pre-Authenticated Request) de lectura para ese `.zip`.
4. Copia la URL del PAR y reemplaza `<PACKAGE_URL>` en este botón:

[![Deploy to Oracle Cloud](https://oci-resourcemanager-plugin.plugins.oci.oraclecloud.com/latest/deploy-to-oracle-cloud.svg)](https://cloud.oracle.com/resourcemanager/stacks/create?zipUrl=<PACKAGE_URL>)

5. Se abrirá `Create Stack` en OCI. Completa:
   - Stack name: por ejemplo `oci-foundation-stack`.
   - Compartment: el compartment donde guardas el stack en Resource Manager.
   - Terraform version: deja la recomendada por OCI.
6. En variables del stack, completa al menos:
   - `tenancy_ocid`
   - `region`
   - `api_key_user_ocid`
   - `ssh_public_key` (opcional; si queda vacío, se genera automáticamente)
   - `atp_admin_password`
   - `ssh_allowed_cidr` (tu IP/CIDR real)
7. Crea el stack.
8. Ejecuta `Plan` y revisa cambios.
9. Ejecuta `Apply`.
10. Revisa `Outputs` del job para obtener OCIDs, IP pública de VM y endpoint de AIDP.

### Opción B: Subiendo el `.zip` directamente en Resource Manager

1. En OCI Console, ve a: `Developer Services` -> `Resource Manager` -> `Stacks`.
2. Click en `Create stack`.
3. En `Stack configuration`, selecciona `My configuration`.
4. En `Terraform template`, selecciona `Upload .zip file` y carga el `.zip` de `utils/oci-foundation-stack`.
5. Click en `Next`.
6. En `Configure variables`, completa los mismos campos mínimos de la opción A.
7. Click en `Next` -> `Create`.
8. Ejecuta `Plan` y luego `Apply`.
9. Revisa `Logs` y `Outputs` del job.

## Cómo generar el `.zip` en PowerShell

Desde la raíz del repo:

```powershell
Compress-Archive `
  -Path .\utils\oci-foundation-stack\*.tf,
        .\utils\oci-foundation-stack\*.md,
        .\utils\oci-foundation-stack\*.hcl,
        .\utils\oci-foundation-stack\terraform.tfvars.example,
        .\utils\oci-foundation-stack\scripts\* `
  -DestinationPath .\utils\oci-foundation-stack-rm.zip `
  -Force
```

## Uso local con Terraform

1. Ir a la carpeta:

```powershell
cd utils/oci-foundation-stack
```

2. Inicializar:

```powershell
terraform init
```

3. Preparar variables:

```powershell
Copy-Item terraform.tfvars.example terraform.tfvars
# Edita terraform.tfvars con tus OCIDs y llaves
```

4. Validar y planear:

```powershell
terraform validate
terraform plan
```

5. Aplicar:

```powershell
terraform apply
```

## Nota importante sobre ATP

Con el provider OCI usado por este stack, el atributo disponible en Terraform es `data_storage_size_in_tbs`. Por eso se usa `atp_data_storage_tbs = 1` (equivalente a 1 TB).

## Nota sobre AIDP Workbench

Este stack usa el recurso Terraform `oci_ai_data_platform_ai_data_platform` con `ai_data_platform_type = "WORKBENCH"`.

En varios tenants trial puede fallar por permisos/dominio (`NotAuthorizedOrNotFound` sobre domain). Por eso se recomienda:

- `policy_group_name = "Default/Administrators"` (si aplica en tu tenancy)
- `enable_aidp_iam_policies = true`
- `aidp_use_tenancy_policies = true`
- Si aún falla por limitación del tenant, usar `enable_aidp_workbench = false` temporalmente.

## Nota de riesgo (acceso abierto de laboratorio)

Con esta configuración por defecto, SSH y puertos de app quedan expuestos a internet. Para ambientes reales, restringe CIDRs antes de desplegar.

## Nota de riesgo (API keys)

Guardar la llave privada en bucket fue incorporado por requerimiento de laboratorio. Para producción, migrar esa llave a OCI Vault/Secrets y rotar periódicamente.

## Fuentes oficiales del botón Resource Manager

- [Using the Deploy to Oracle Cloud Button](https://docs.oracle.com/en-us/iaas/Content/ResourceManager/Tasks/deploybutton.htm)







## Recomendacion para trial estable

Para evitar fallos por servicios no habilitados/policies incompletas en trial, usa:

- `enable_aidp_workbench = false`
- `enable_object_storage_artifacts = false`
- `store_api_private_key_in_bucket = false`
- `store_vm_ssh_keys_in_bucket = false`


## Credenciales en outputs (copia manual)

Si quieres que el job muestre al final las llaves/credenciales para copiar manualmente, usa:

- `expose_sensitive_credentials_in_outputs = true`

Outputs relevantes:

- `manual_copy_credentials`
- `generated_ssh_private_key_pem_for_copy`
- `api_private_key_pem_for_copy`

Advertencia: estos outputs exponen material sensible en logs del job. Usar solo en laboratorio.




## Archivo OCI config en bucket

Cuando `enable_object_storage_artifacts=true` y `enable_bucket_object_uploads=true`, el stack crea tambien:

- `keys/oci_config`

Con formato:

```ini
[DEFAULT]
user=<api_key_user_ocid>
fingerprint=<api_key_fingerprint>
tenancy=<tenancy_ocid>
region=<region>
key_file=<path to your private keyfile> # TODO
```
