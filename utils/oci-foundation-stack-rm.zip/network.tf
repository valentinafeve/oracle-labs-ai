resource "oci_identity_compartment" "lab" {
  compartment_id = var.tenancy_ocid
  name           = local.normalized_compartment_name
  description    = var.compartment_description
  enable_delete  = true

  freeform_tags = var.freeform_tags
}

resource "oci_core_vcn" "lab_vcn" {
  compartment_id = oci_identity_compartment.lab.id
  display_name   = var.vcn_display_name
  cidr_block     = var.vcn_cidr
  dns_label      = "labvcn"

  freeform_tags = var.freeform_tags
}

resource "oci_core_internet_gateway" "lab_igw" {
  compartment_id = oci_identity_compartment.lab.id
  vcn_id         = oci_core_vcn.lab_vcn.id
  display_name   = "${var.vcn_display_name}-igw"
  enabled        = true

  freeform_tags = var.freeform_tags
}

resource "oci_core_route_table" "public_rt" {
  compartment_id = oci_identity_compartment.lab.id
  vcn_id         = oci_core_vcn.lab_vcn.id
  display_name   = "${var.vcn_display_name}-public-rt"

  route_rules {
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_internet_gateway.lab_igw.id
  }

  freeform_tags = var.freeform_tags
}

resource "oci_core_security_list" "public_sl" {
  compartment_id = oci_identity_compartment.lab.id
  vcn_id         = oci_core_vcn.lab_vcn.id
  display_name   = "${var.vcn_display_name}-public-sl"

  ingress_security_rules {
    protocol = "6"
    source   = var.ssh_allowed_cidr

    tcp_options {
      min = 22
      max = 22
    }
  }

  dynamic "ingress_security_rules" {
    for_each = var.enable_public_app_ports ? [8080, 1521] : []
    content {
      protocol = "6"
      source   = var.app_ports_cidr

      tcp_options {
        min = ingress_security_rules.value
        max = ingress_security_rules.value
      }
    }
  }

  egress_security_rules {
    protocol    = "all"
    destination = "0.0.0.0/0"
  }

  freeform_tags = var.freeform_tags
}

resource "oci_core_subnet" "public_subnet" {
  compartment_id             = oci_identity_compartment.lab.id
  vcn_id                     = oci_core_vcn.lab_vcn.id
  display_name               = var.public_subnet_display_name
  cidr_block                 = var.public_subnet_cidr
  dns_label                  = "pubsub"
  route_table_id             = oci_core_route_table.public_rt.id
  security_list_ids          = [oci_core_security_list.public_sl.id]
  prohibit_public_ip_on_vnic = false

  freeform_tags = var.freeform_tags
}
