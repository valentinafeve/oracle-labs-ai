locals {
  base_policy_statements = var.allow_any_user_manage_all_resources ? [
    "Allow any-user to manage all-resources in compartment ${local.normalized_compartment_name}"
    ] : [
    "Allow group ${var.policy_group_name} to manage virtual-network-family in compartment ${local.normalized_compartment_name}",
    "Allow group ${var.policy_group_name} to manage instance-family in compartment ${local.normalized_compartment_name}",
    "Allow group ${var.policy_group_name} to manage autonomous-database-family in compartment ${local.normalized_compartment_name}",
    "Allow group ${var.policy_group_name} to manage object-family in compartment ${local.normalized_compartment_name}",
    "Allow group ${var.policy_group_name} to read compartments in tenancy"
  ]

  rm_service_policy_statements = trimspace(var.resource_manager_service_principal) != "" ? [
    "Allow service ${trimspace(var.resource_manager_service_principal)} to manage object-family in compartment ${local.normalized_compartment_name}"
  ] : []

  policy_statements = concat(local.base_policy_statements, local.rm_service_policy_statements)

  # Basado en la guia oficial AIDP.
  aidp_policy_statements_tenancy = [
    "Allow group ${var.policy_group_name} to manage ai-data-platforms in compartment id ${oci_identity_compartment.lab.id}",
    "Allow any-user to {AUTHENTICATION_INSPECT, DOMAIN_INSPECT, DOMAIN_READ, DYNAMIC_GROUP_INSPECT, GROUP_INSPECT, GROUP_MEMBERSHIP_INSPECT, USER_INSPECT, USER_READ} in tenancy where all {request.principal.type='aidataplatform'}",
    "Allow any-user to manage log-groups in tenancy where all {request.principal.type='aidataplatform'}",
    "Allow any-user to read log-content in tenancy where all {request.principal.type='aidataplatform'}",
    "Allow any-user to use metrics in tenancy where all {request.principal.type='aidataplatform', target.metrics.namespace='oracle_aidataplatform'}",
    "Allow any-user to manage buckets in tenancy where all {request.principal.type='aidataplatform', any {request.permission='BUCKET_CREATE', request.permission='BUCKET_INSPECT', request.permission='BUCKET_READ', request.permission='BUCKET_UPDATE'}}",
    "Allow any-user to {TAG_NAMESPACE_USE} in tenancy where all {request.principal.type='aidataplatform'}",
    "Allow any-user to manage buckets in tenancy where all {request.principal.id=target.resource.tag.orcl-aidp.governingAidpId, any {request.permission='BUCKET_DELETE', request.permission='PAR_MANAGE', request.permission='RETENTION_RULE_LOCK', request.permission='RETENTION_RULE_MANAGE'}}",
    "Allow any-user to read objectstorage-namespaces in tenancy where all {request.principal.type='aidataplatform', any {request.permission='OBJECTSTORAGE_NAMESPACE_READ'}}",
    "Allow any-user to manage objects in tenancy where all {request.principal.id=target.bucket.system-tag.orcl-aidp.governingAidpId}",
    "Allow any-user to manage vnics in tenancy where all {request.principal.type='aidataplatform'}",
    "Allow any-user to use subnets in tenancy where all {request.principal.type='aidataplatform'}",
    "Allow any-user to use network-security-groups in tenancy where all {request.principal.type='aidataplatform'}"
  ]

  aidp_policy_statements_compartment = [
    "Allow group ${var.policy_group_name} to manage ai-data-platforms in compartment id ${oci_identity_compartment.lab.id}",
    "Allow any-user to {AUTHENTICATION_INSPECT, DOMAIN_INSPECT, DOMAIN_READ, DYNAMIC_GROUP_INSPECT, GROUP_INSPECT, GROUP_MEMBERSHIP_INSPECT, USER_INSPECT, USER_READ} in tenancy where all {request.principal.type='aidataplatform'}",
    "Allow any-user to manage log-groups in compartment id ${oci_identity_compartment.lab.id} where all {request.principal.type='aidataplatform'}",
    "Allow any-user to read log-content in compartment id ${oci_identity_compartment.lab.id} where all {request.principal.type='aidataplatform'}",
    "Allow any-user to use metrics in compartment id ${oci_identity_compartment.lab.id} where all {request.principal.type='aidataplatform', target.metrics.namespace='oracle_aidataplatform'}",
    "Allow any-user to manage buckets in compartment id ${oci_identity_compartment.lab.id} where all {request.principal.type='aidataplatform', any {request.permission='BUCKET_CREATE', request.permission='BUCKET_INSPECT', request.permission='BUCKET_READ', request.permission='BUCKET_UPDATE'}}",
    "Allow any-user to {TAG_NAMESPACE_USE} in tenancy where all {request.principal.type='aidataplatform'}",
    "Allow any-user to manage buckets in compartment id ${oci_identity_compartment.lab.id} where all {request.principal.id=target.resource.tag.orcl-aidp.governingAidpId, any {request.permission='BUCKET_DELETE', request.permission='PAR_MANAGE', request.permission='RETENTION_RULE_LOCK', request.permission='RETENTION_RULE_MANAGE'}}",
    "Allow any-user to read objectstorage-namespaces in compartment id ${oci_identity_compartment.lab.id} where all {request.principal.type='aidataplatform', any {request.permission='OBJECTSTORAGE_NAMESPACE_READ'}}",
    "Allow any-user to manage objects in compartment id ${oci_identity_compartment.lab.id} where all {request.principal.id=target.bucket.system-tag.orcl-aidp.governingAidpId}",
    "Allow any-user to manage vnics in compartment id ${oci_identity_compartment.lab.id} where all {request.principal.type='aidataplatform'}",
    "Allow any-user to use subnets in compartment id ${oci_identity_compartment.lab.id} where all {request.principal.type='aidataplatform'}",
    "Allow any-user to use network-security-groups in compartment id ${oci_identity_compartment.lab.id} where all {request.principal.type='aidataplatform'}"
  ]

  aidp_policy_statements = var.enable_aidp_iam_policies ? (var.aidp_use_tenancy_policies ? local.aidp_policy_statements_tenancy : local.aidp_policy_statements_compartment) : []
}

resource "oci_identity_policy" "lab_policy" {
  compartment_id = var.tenancy_ocid
  name           = var.policy_name
  description    = "Políticas base para operar recursos del laboratorio en el compartment ${local.normalized_compartment_name}."

  statements = local.policy_statements

  freeform_tags = var.freeform_tags

  depends_on = [oci_identity_compartment.lab]
}

resource "oci_identity_policy" "aidp_policy" {
  count = var.enable_aidp_workbench && var.enable_aidp_iam_policies ? 1 : 0

  compartment_id = var.tenancy_ocid
  name           = "${var.policy_name}-aidp"
  description    = "Políticas IAM para OCI AI Data Platform Workbench."

  statements = local.aidp_policy_statements

  freeform_tags = var.freeform_tags

  depends_on = [oci_identity_compartment.lab]
}

resource "time_sleep" "wait_aidp_policy_ready" {
  count = var.enable_aidp_workbench && var.enable_aidp_iam_policies ? 1 : 0

  depends_on = [
    oci_identity_policy.lab_policy,
    oci_identity_policy.aidp_policy
  ]
  create_duration = "240s"
}
