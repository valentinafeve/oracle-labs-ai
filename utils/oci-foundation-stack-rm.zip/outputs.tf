output "compartment_ocid" {
  description = "OCID del compartment creado."
  value       = oci_identity_compartment.lab.id
}

output "vcn_ocid" {
  description = "OCID de la VCN creada."
  value       = oci_core_vcn.lab_vcn.id
}

output "public_subnet_ocid" {
  description = "OCID de la subnet pública."
  value       = oci_core_subnet.public_subnet.id
}

output "vm_public_ip" {
  description = "IP pública primaria de la VM Oracle Linux 9."
  value       = oci_core_instance.docker_vm.public_ip
}

output "atp_ocid" {
  description = "OCID de la ATP creada."
  value       = oci_database_autonomous_database.atp.id
}

output "object_storage_bucket" {
  description = "Bucket donde se dejaron llaves/artefactos (si esta habilitado)."
  value       = try(oci_objectstorage_bucket.artifacts[0].name, null)
}

output "api_key_fingerprint" {
  description = "Fingerprint de la API key creada para el usuario indicado."
  value       = oci_identity_api_key.lab_user_key.fingerprint
}

output "policy_mode" {
  description = "Modo de política aplicado: legacy_any_user o least_privilege_group."
  value       = var.allow_any_user_manage_all_resources ? "legacy_any_user" : "least_privilege_group"
}

output "security_note" {
  description = "Advertencia de seguridad sobre llaves privadas."
  value       = "Si almacenas la llave privada de API en Object Storage, considera migrarla a OCI Vault/Secrets y rotarla periódicamente."
}

output "aidp_workbench_ocid" {
  description = "OCID del servicio OCI AI Data Platform Workbench (si está habilitado)."
  value       = try(oci_ai_data_platform_ai_data_platform.aidp_workbench[0].id, null)
}

output "aidp_workbench_websocket_endpoint" {
  description = "WebSocket endpoint de AIDP Workbench (si está habilitado)."
  value       = try(oci_ai_data_platform_ai_data_platform.aidp_workbench[0].web_socket_endpoint, null)
}

output "generated_ssh_public_key_openssh" {
  description = "Llave publica SSH autogenerada (si ssh_public_key se dejó vacía)."
  value       = try(tls_private_key.vm_ssh_key[0].public_key_openssh, null)
}

output "generated_ssh_private_key_pem" {
  description = "Llave privada SSH autogenerada (si ssh_public_key se dejó vacía)."
  value       = try(tls_private_key.vm_ssh_key[0].private_key_pem, null)
  sensitive   = true
}


output "generated_ssh_private_key_pem_for_copy" {
  description = "Llave privada SSH visible para copia manual (solo laboratorio)."
  value       = var.expose_sensitive_credentials_in_outputs ? nonsensitive(try(tls_private_key.vm_ssh_key[0].private_key_pem, null)) : null
  sensitive   = false
}

output "api_private_key_pem_for_copy" {
  description = "API private key visible para copia manual (solo laboratorio)."
  value       = var.expose_sensitive_credentials_in_outputs ? nonsensitive(tls_private_key.api_signing_key.private_key_pem) : null
  sensitive   = false
}

output "manual_copy_credentials" {
  description = "Bloque de texto para copiar credenciales manualmente (solo laboratorio)."
  value = var.expose_sensitive_credentials_in_outputs ? nonsensitive(join("\n", compact([
    "===== LAB CREDENTIALS (COPY) =====",
    format("VM_PUBLIC_IP=%s", try(oci_core_instance.docker_vm.public_ip, "")),
    format("API_KEY_FINGERPRINT=%s", try(oci_identity_api_key.lab_user_key.fingerprint, "")),
    format("BUCKET_NAME=%s", try(oci_objectstorage_bucket.artifacts[0].name, "")),
    format("ATP_ADMIN_PASSWORD=%s", var.atp_admin_password),
    "----- SSH_PUBLIC_KEY -----",
    try(tls_private_key.vm_ssh_key[0].public_key_openssh, ""),
    "----- SSH_PRIVATE_KEY_PEM -----",
    try(tls_private_key.vm_ssh_key[0].private_key_pem, ""),
    "----- OCI_API_PUBLIC_KEY_PEM -----",
    tls_private_key.api_signing_key.public_key_pem,
    "----- OCI_API_PRIVATE_KEY_PEM -----",
    tls_private_key.api_signing_key.private_key_pem,
    "===== END LAB CREDENTIALS ====="
  ]))) : "Credenciales sensibles ocultas. Activa expose_sensitive_credentials_in_outputs=true para mostrarlas."
  sensitive = false
}
